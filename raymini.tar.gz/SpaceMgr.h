/*
 * KDTree.h
 *
 *  Created on: May 4, 2012
 *      Author: emile
 */

#ifndef SPACEMGR_H_
#define SPACEMGR_H_

#include "Ray.h"
#include "Vec3D.h"
#include "BoundingBox.h"
#include "Triangle.h"
#include "Scene.h"
#include "Object.h"
#include "Vertex.h"
#include <vector>
#include <iostream>
#include <utility>

using std::vector;
using std::pair;
using std::ostream;
using std::make_pair;

enum SplitDir {
	SplitDirX = 0,
	SplitDirY = 1,
	SplitDirZ = 2,
	SplitDirNumber = 3
};

enum NodeType {
	NodeTypeLeaf = 0,
	NodeTypeInternal = 1
};

struct KDTree2 {
	NodeType _type;
	KDTree2 *_pKids[2];
	vector<Triangle> *_pTriangles;
	BoundingBox *_pBox;
	const Object *_pObj;

	KDTree2() {
		_type = NodeTypeInternal;
		_pKids[0] = NULL;
		_pKids[1] = NULL;
		_pTriangles = NULL;
		_pBox = NULL;
		_pObj = NULL;
	}

	static KDTree2 *creatTree(const vector<Triangle> &triangles_, const BoundingBox &box_, const Object *pObj_, int depth_);

	static bool isTrInBox(const Triangle &tr_, const BoundingBox &box_, const vector<Vertex> &vertices_);

	bool getPtIntersect(const Ray &ray_, Vertex &ans_, float &dist_);

	~KDTree2() {
		if (_type == NodeTypeInternal) {
			delete _pBox;
			delete _pKids[0];
			delete _pKids[1];
		}
		else {
			delete _pTriangles;
			delete _pBox;
		}
	}

	const BoundingBox & getBoundingBox () const {
		return *_pBox;
	}

	void print(ostream &out_, int depth_) const;
};

ostream &operator <<(ostream &out_, const KDTree2 &kdt_);

class SpaceMgr {
public:
	SpaceMgr(const Scene &scene_);
	pair<const Object *, Vertex> getPtIntersect(const Ray &ray_);
	~SpaceMgr();
private:
	vector<KDTree2 *> _trees;
};

#endif /* SPACEMGR_H_ */
