/*
 * KDTree.cpp
 *
 *  Created on: May 4, 2012
 *      Author: emile
 */

#include "SpaceMgr.h"
#include "Object.h"
#include "Scene.h"
#include "Ray.h"
#include "Vec3D.h"
#include "BoundingBox.h"
#include <vector>
#include <functional>
#include <algorithm>
#include <utility>
#include <limits>
using namespace std;

SpaceMgr::SpaceMgr(const Scene &scene_) {
	for (vector<Object>::const_iterator oit = scene_.getObjects().begin();
			oit != scene_.getObjects().end(); ++oit) {
		this->_trees.push_back(KDTree2::creatTree(oit->getMesh().getTriangles(), oit->getBoundingBox(), &(*oit), 0));
	}
}

SpaceMgr::~SpaceMgr() {
	for (vector<KDTree2 *>::iterator tit = this->_trees.begin();
			tit != this->_trees.end(); ++tit) {
		delete *tit;
	}
}

pair<const Object *, Vertex>
SpaceMgr::getPtIntersect(const Ray &ray_) {
	float minDistQuad = std::numeric_limits<float>::max();
	const Object *objClose = NULL;
	Vertex vexClose;
	Vertex vexCand;
	float dist;
	for (vector<KDTree2 *>::iterator tit = this->_trees.begin();
			tit != this->_trees.end(); ++tit) {
		if ((*tit)->getPtIntersect(ray_, vexCand, dist)) {
			if (dist < minDistQuad) {
				minDistQuad = dist;
				objClose = (*tit)->_pObj;
				vexClose = vexCand;
			}
		}
	}
	return make_pair(objClose, vexClose);
}

bool KDTree2::isTrInBox(const Triangle &tr_, const BoundingBox &box_, const vector<Vertex> &vertices_) {
	BoundingBox tbox(vertices_[tr_.getVertex(0)].getPos());
	tbox.extendTo(vertices_[tr_.getVertex(1)].getPos());
	tbox.extendTo(vertices_[tr_.getVertex(2)].getPos());
	return box_.contains(tbox);
}

KDTree2 *KDTree2::creatTree(const vector<Triangle> &triangles_, const BoundingBox &box_, const Object *pObj_, int depth_) {
//	cout << "triangles_.size() = " << triangles_.size() << endl;
	if (triangles_.size() == 0)
		return NULL;
	SplitDir d = static_cast<SplitDir>(depth_ % SplitDirNumber);
	const vector<Vertex> &vertices = pObj_->getMesh().getVertices();
	vector<float> vals;
	vals.reserve(triangles_.size() * 3);
	for (vector<Triangle>::const_iterator tr = triangles_.begin(); tr != triangles_.end(); ++tr) {
		vals.push_back(vertices[tr->getVertex(0)].getPos()[d]);
		vals.push_back(vertices[tr->getVertex(1)].getPos()[d]);
		vals.push_back(vertices[tr->getVertex(2)].getPos()[d]);
	}
	std::nth_element(vals.begin(), vals.begin() + vals.size()/2, vals.end());
//	float median = (box_.getMin()[d] + box_.getMax()[d])/2.0f;
	float median = vals[vals.size()/2];

	BoundingBox *pBox[2] = { new BoundingBox(box_.getMin(), box_.getMin()), new BoundingBox(box_.getMax(), box_.getMax()) };
	switch (d) {
	case SplitDirX:
		pBox[0]->extendTo(Vec3Df(median, box_.getMax()[1], box_.getMax()[2]));
		pBox[1]->extendTo(Vec3Df(median, box_.getMin()[1], box_.getMin()[2]));
		break;
	case SplitDirY:
		pBox[0]->extendTo(Vec3Df(box_.getMax()[0], median, box_.getMax()[2]));
		pBox[1]->extendTo(Vec3Df(box_.getMin()[0], median, box_.getMin()[2]));
		break;
	case SplitDirZ:
		pBox[0]->extendTo(Vec3Df(box_.getMax()[0], box_.getMax()[1], median));
		pBox[1]->extendTo(Vec3Df(box_.getMin()[0], box_.getMin()[1], median));
		break;
	default:
		break;
	}
	vector<Triangle> *newVec[2];
	newVec[0]= new vector<Triangle>;
	newVec[1] = new vector<Triangle>;
	{
		for (vector<Triangle>::const_iterator tr = triangles_.begin();
				tr != triangles_.end(); ++tr) {
			for (int k = 0; k < 2; k++) {
				if (isTrInBox(*tr, *pBox[k], vertices)) {
					newVec[k]->push_back(*tr);
				}
			}
		}
	}

	if (newVec[0]->size() == triangles_.size() || newVec[1]->size() == triangles_.size()) {
		KDTree2 *pt = new KDTree2;
		pt->_pObj = pObj_;
		pt->_type = NodeTypeLeaf;

		if (newVec[0]->size() == triangles_.size()) {
			pt->_pBox = pBox[0];
			pt->_pTriangles = newVec[0];
			delete pBox[1];
			delete newVec[1];
		}
		else {
			pt->_pBox = pBox[1];
			pt->_pTriangles = newVec[1];
			delete pBox[0];
			delete newVec[0];
		}

		return pt;
	}
	else {
		KDTree2 *pt = new KDTree2;
		pt->_pObj = pObj_;
		pt->_type = NodeTypeInternal;
		pt->_pBox = new BoundingBox(pBox[0]->getMin(), pBox[0]->getMax());
		pt->_pBox->extendTo(*pBox[1]);
		pt->_pTriangles = NULL;
		pt->_pKids[0] = creatTree(*newVec[0], *pBox[0], pObj_, depth_+1);
		pt->_pKids[1] = creatTree(*newVec[1], *pBox[1], pObj_, depth_+1);
		delete pBox[0];
		delete pBox[1];
		delete newVec[0];
		delete newVec[1];
		return pt;
	}
	return NULL;
}

bool KDTree2::getPtIntersect(const Ray &ray_, Vertex &ans_, float &dist_) {
//	cout << "[" << _pBox->getMin() << ";";
//	cout << _pBox->getMax() << "]" << endl;
	if (this->_type == NodeTypeLeaf) {
		float t, u, v;
		Ray ray(ray_.getOrigin() - _pObj->getTrans(), ray_.getDirection());
		const vector<Vertex> &vertices = _pObj->getMesh().getVertices();
		Vertex ptInsectTmp;
		Vec3Df tmpNorm;
		float dtmp = dist_ = std::numeric_limits<float>::max();
		for (vector<Triangle>::iterator tr = _pTriangles->begin();
				tr != _pTriangles->end(); ++tr) {
//			cout << "<" << vertices[tr->getVertex(0)].getPos() << "," << vertices[tr->getVertex(1)].getPos() << "," << vertices[tr->getVertex(2)].getPos() << ">" << endl;
			if (ray.intersect(vertices[tr->getVertex(0)].getPos(),
					vertices[tr->getVertex(1)].getPos(),
					vertices[tr->getVertex(2)].getPos(), t, u, v)) {
				ptInsectTmp.setPos(
						(1.0f - u - v) * vertices[tr->getVertex(0)].getPos()
								+ u * vertices[tr->getVertex(1)].getPos()
								+ v * vertices[tr->getVertex(2)].getPos()
								+ _pObj->getTrans());
				if (Vec3Df::dotProduct(ptInsectTmp.getPos() - ray_.getOrigin(),
						ray_.getDirection()) < 0)
					continue;
				if ((dtmp = Vec3Df::squaredDistance(ptInsectTmp.getPos(),
						ray_.getOrigin())) < dist_) {
					dist_ = dtmp;
					ans_.setPos(ptInsectTmp.getPos());
					tmpNorm = (1.f - u - v) * vertices[tr->getVertex(0)].getNormal()
							+ u * vertices[tr->getVertex(1)].getNormal()
							+ v * vertices[tr->getVertex(2)].getNormal();
					tmpNorm.normalize();
					ans_.setNormal(tmpNorm);
				}
			}
		}
		if (dist_ < std::numeric_limits<float>::max()) {
			return true;
		}
		return false;
	}
	else {
		Ray ray(ray_.getOrigin() - _pObj->getTrans(), ray_.getDirection());
		Vec3Df ptTmp0, ptTmp1;
		float dist0 = std::numeric_limits<float>::max(), dist1 =
				std::numeric_limits<float>::max();
		if (this->getBoundingBox().contains(ray.getOrigin())) {

			if (this->_pKids[0]->getBoundingBox().contains(ray.getOrigin())) {
				if (_pKids[0]->getPtIntersect(ray_, ans_, dist_))
					return true;
				if (_pKids[1]->getPtIntersect(ray_, ans_, dist_))
					return true;
			}

			if (this->_pKids[1]->getBoundingBox().contains(ray.getOrigin())) {
				if (_pKids[1]->getPtIntersect(ray_, ans_, dist_))
					return true;
				if (_pKids[0]->getPtIntersect(ray_, ans_, dist_))
					return true;
			}

			return false;
		}
		else {

			if (ray.intersect(this->_pKids[0]->getBoundingBox(), ptTmp0)) {
				dist0 = Vec3Df::squaredDistance(ptTmp0, ray_.getOrigin());
			}

			if (ray.intersect(this->_pKids[1]->getBoundingBox(), ptTmp1)) {
				dist1 = Vec3Df::squaredDistance(ptTmp1, ray_.getOrigin());
			}

			KDTree2 *kids[2] = { this->_pKids[0], this->_pKids[1] };

			if (dist1 < dist0) {
				std::swap(kids[0], kids[1]);
				std::swap(dist0, dist1);
			}

			if (dist0 < std::numeric_limits<float>::max())
				if (kids[0]->getPtIntersect(ray_, ans_, dist_))
					return true;

			if (dist1 < std::numeric_limits<float>::max())
				if (kids[1]->getPtIntersect(ray_, ans_, dist_))
					return true;

			return false;
		}
	}
	return false;
}

ostream &operator <<(ostream &out_, const KDTree2 &kdt_) {
	kdt_.print(out_, 0);
	return out_;
}

void KDTree2::print(ostream &out_, int depth_) const {
	using std::endl;
	const vector<Vertex> &vertices = _pObj->getMesh().getVertices();
	for (int k = 0; k < depth_; ++k)
		out_ << " ";
	out_ << depth_ << ":";
	out_ << "[";
	out_ << "[" << _pBox->getMin() << "," << _pBox->getMax() << "]" << endl;
	if (_type == NodeTypeLeaf) {
//		for (vector<Triangle>::iterator tr = _pTriangles->begin();
//				tr != _pTriangles->end(); ++tr) {
//			out_ << "[";
//			out_ << vertices[tr->getVertex(0)].getPos() << ",";
//			out_ << vertices[tr->getVertex(1)].getPos() << ",";
//			out_ << vertices[tr->getVertex(2)].getPos() << "]";
//			out_ << endl;
//		}
	}
	else {
		this->_pKids[0]->print(out_, depth_ + 1);
		this->_pKids[1]->print(out_, depth_ + 1);
	}
	for (int k = 0; k < depth_; ++k)
		out_ << " ";
	out_ << "]" << endl;
}
